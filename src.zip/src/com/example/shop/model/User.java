package com.example.shop.model;

public class User {
}
